Class S3B1.Main
{

ClassMethod Hello() As %String
{
    quit "hello from s3-b1 1.0.0"
}

}
