Class S3B2.Main
{

ClassMethod Hello() As %String
{
    quit "hello from s3-b2 1.0.0"
}

}
