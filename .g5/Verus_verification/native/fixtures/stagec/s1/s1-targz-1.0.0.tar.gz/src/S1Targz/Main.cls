Class S1Targz.Main
{

ClassMethod Hello() As %String
{
    quit "hello from s1-targz 1.0.0"
}

}
