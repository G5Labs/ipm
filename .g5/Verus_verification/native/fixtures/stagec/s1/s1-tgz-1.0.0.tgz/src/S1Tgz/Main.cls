Class S1Tgz.Main
{

ClassMethod Hello() As %String
{
    quit "hello from s1-tgz 1.0.0"
}

}
